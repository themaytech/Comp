import React from "react";

function uploadFile (){
    return (
        <>
            <div className="container">
                <h2>
                    Drag and Drop Here 
                </h2>
            </div>
            <div className="display">
                <h3>
                    Uploaded
                </h3>
            </div>
        </>
    )
}

export default uploadFile;